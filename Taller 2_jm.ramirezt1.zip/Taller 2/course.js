"use strict";
exports.__esModule = true;
exports.Course = void 0;
var Course = /** @class */ (function () {
    function Course(name, professor, credits) {
        this.name = name;
        this.credits = credits;
        this.professor = professor;
    }
    return Course;
}());
exports.Course = Course;
