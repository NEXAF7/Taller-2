"use strict";
exports.__esModule = true;
exports.dataCourses = void 0;
var course_js_1 = require("./course.js");
exports.dataCourses = [
    new course_js_1.Course("Desarrollo de Sw en Equipo", "Rubby Casallas", 3),
    new course_js_1.Course("Infraestructura Computacional", "Harold Castro", 3),
    new course_js_1.Course("Lenguajes y Máquinas", "Silvia Takahashi", 3),
    new course_js_1.Course("TI en las Organizaciones", "Disney Rubiano", 3),
    new course_js_1.Course("Cálculo Vectorial", "Jairo Cárdenas", 3),
    new course_js_1.Course("Física II", "Neelima Kelkar", 3),
    new course_js_1.Course("Física Experimental II", "John Rubio", 1),
    new course_js_1.Course("Inglés IV", "Valeriya Lytvychenko", 2)
];
