import { Course } from './course.js';

export const dataCourses = [
  new Course("Desarrollo de Sw en Equipo", "Rubby Casallas", 3),
  new Course("Infraestructura Computacional", "Harold Castro", 3),
  new Course("Lenguajes y Máquinas", "Silvia Takahashi", 3),
  new Course("TI en las Organizaciones", "Disney Rubiano", 3),
  new Course("Cálculo Vectorial", "Jairo Cárdenas", 3),
  new Course("Física II", "Neelima Kelkar", 3),
  new Course("Física Experimental II", "John Rubio", 1),
  new Course("Inglés IV", "Valeriya Lytvychenko", 2)
] 