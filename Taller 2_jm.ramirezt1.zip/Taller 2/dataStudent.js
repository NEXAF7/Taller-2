"use strict";
exports.__esModule = true;
exports.dataStudent = void 0;
var student_js_1 = require("./student.js");
exports.dataStudent = new student_js_1.student("Juan Manuel Ramírez Tamayo", 202013256, 1000454399, 20, "529 Cranbrooke Ave", "+1 (647) 229-7666");
