import { student } from './student.js';

export const dataStudent = new student("Juan Manuel Ramírez Tamayo", 202013256, 1000454399, 20, "529 Cranbrooke Ave", "+1 (647) 229-7666");